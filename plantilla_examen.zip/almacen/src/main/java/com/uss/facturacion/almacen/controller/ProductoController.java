package com.uss.facturacion.almacen.controller;

public class ProductoController {

}
