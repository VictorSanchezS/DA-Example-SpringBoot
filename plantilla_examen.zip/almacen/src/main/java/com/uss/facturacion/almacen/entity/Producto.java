package com.uss.facturacion.almacen.entity;

public class Producto {

}
