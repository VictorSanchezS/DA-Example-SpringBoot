package com.uss.facturacion.almacen.repository;

public interface ProductoRepository {

}
