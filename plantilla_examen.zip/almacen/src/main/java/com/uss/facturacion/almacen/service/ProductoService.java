package com.uss.facturacion.almacen.service;

public interface ProductoService {

}
