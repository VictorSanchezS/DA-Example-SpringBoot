package com.uss.facturacion.almacen.service.impl;

public class ProductoServiceImpl {

}
